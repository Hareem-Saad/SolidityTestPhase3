import { ethers } from "hardhat";
import "ethereum-cryptography/utils";
import { utf8ToBytes } from "ethereum-cryptography/utils";

async function main() {
  // const lockedAmount = ethers.utils.parseEther("1");
  const [school, teacher, student] = await ethers.getSigners();

  const Contract = await ethers.getContractFactory("School");
  const contract = await Contract.deploy();

  const CertificateContract = await ethers.getContractFactory("Certificate");
  const certificateContract = await CertificateContract.attach(await contract.certificateContract());

  const QTKNContract = await ethers.getContractFactory("tokenQTKN");
  const qtknContract = await QTKNContract.attach(await contract.qtknContract());

  const CourseNFTContract = await ethers.getContractFactory("CourseNFT");
  const CourseNftContract = await CourseNFTContract.attach(await contract.cnft());

  const PTKNContract = await ethers.getContractFactory("proxyTKN");
  const ptknContract = await PTKNContract.attach(await contract.ptknContract());

  await contract.deployed();

  console.log(`School: ${contract.address}\nCertificate Contract: ${certificateContract.address}\nQTKN Contract: ${qtknContract.address}\nCourse NFT: ${CourseNftContract.address}\nPTKN Contract: ${ptknContract.address}`);

  /**
   * data comes from front end, it gets concatenated, turned to bytes string
   * eg: 0 ICS 0x5B38Da6a701c568545dCfcB03FcB875f56beddC4 50000000000000000000 10 56500000000000000000 6500000000000000000
   * courseid, course name, teacher addr, teacher's price, share term, course price, school price (course price - teacher's price)
   */
  const CName = "ICS"
  const shareTerm = 10
  const price = 50
  const teachersPrice = (await contract.calculatePrice(price, shareTerm)).toBigInt() - ((await contract.calculateTaxPrice(price)).toBigInt() + (await contract.calculateSharePrice(price, shareTerm)).toBigInt())
  const coursePrice = (await contract.calculatePrice(price, shareTerm)).toBigInt()
  const str = `${contract.courseCounter()} ${CName} ${teacher.address} ${teachersPrice} ${shareTerm} ${coursePrice}  ${coursePrice - teachersPrice}`
  const data = utf8ToBytes(str);
  const tx1 = await (await contract.createCourse(CName, teacher.address, price, shareTerm, data)).wait()
  // console.log(await tx1.events?.at(0)?.getTransactionReceipt());
  console.log(tx1.events?.filter((x) => {return x.event == "minted"}));
  console.log("Teacher creates course");
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
